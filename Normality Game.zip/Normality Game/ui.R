library(shiny)
library(beepr)
library(ggplot2)
#library(shinyjs)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
     # Application title
    titlePanel("Is it Normally Distributed?"),
    br(),
    em("Guess well and gain points; guess poorly and gain only shame (and also lose points)."),
    br(),
    br(),
    textOutput("PointsMaybe"),
    textOutput("PlotNumber"),
    hr(),
    
    sidebarLayout(
        sidebarPanel(
          #useShinyjs(),
         # extendShinyjs(script = "beep.js",functions = c("winprint")),
          radioButtons("pvalguess", label = h3("Is it from a normal distribution?"),
                       choices = list("Probably" = 1, "Unlikely" = 2), 
                       selected = 1),
            actionButton("guess", "Submit Answer"),
            br(),
            br(),
            br(),
            br(),
            br(),
            actionButton("new", "New Plot"),
            br(),
            br(),
            br(),
            br(),
            textOutput("Sass"),
          tags$head(tags$script(src = "message-handler.js")),
            
        ),
        
        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("distPlot"),
            textOutput("Answer")
            
        )
    )
))
