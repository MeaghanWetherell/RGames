library(shiny)
library(beepr)
library(tuneR)
library(ggplot2)
library(shinyjs)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

    compute_data <- function(){
        samplesize <- sample(c(25:175), size = 1)
        rnorm0 <- rnorm(n = samplesize, mean = 60, sd = 3)
        lskew <- 69*rbeta(samplesize,25,3)
        rskew <- 10+69*rbeta(samplesize,3,8)
        bimod <- c(rnorm(n = samplesize/2, mean = 55, sd = 3), rnorm(n = samplesize/2, mean = 65, sd = 3))
        unlist(sample(list(rnorm0, lskew, rskew, bimod), 1)) #randomly take one of these samples
    }
    
    
    
    #####Plot#######
    
    myplot <- function(y, newfill, newcolor){
        df <- data.frame(x = y)
        ggplot(df, aes(x = x))+
            geom_histogram(fill = newfill, col = newcolor, aes(y = ..density..))+
            theme_bw()+
            labs( x = paste("Sample Size:", length(y)), y = "Observation Density")+
            scale_x_continuous(limits = c(min(y) - 2, max(y + 2)))#+
        #labs(title = round(shapiro.test(y)$p.value,3) )
    }
    
    newcolors <- function(){
        sample(c("pink", "salmon", "red", "green", "blue", "lightpink", "hotpink", "greenyellow", "lightcyan", "lightcoral", "lightblue2", "gray", "purple", "darkgreen", "seagreen", "olivedrab", "orange2", "magenta"), 1, replace=TRUE)
    } 
   #################SASS
    
    bad <- c("Nope, WOW", "Oof try again", "are you even playing?", "naw that ain't it", "Look you and I both know that you can do better", "maybe google p values or something", "have you seen a normal distribution before or what", "is ur cat guessing 4 u??", "so close - just kidding, not very close at ALL", "a monkey slamming a keyboard randomly would probably be better at this", "well, we can't all be good at arbitrarily defined statistics games", "a swing and a miss", "WOW. And by WOW I mean Wilks hOnestly Wasntimpressed", "YIKES.", "You know nothing Jon Snow", "Shapir-NO.")
    cheat <- c("you can't guess more than once you cheater", "try new plot, you tried this one already", "oh I see what you are doing but we aren't about that life here", "NO", "you done guessed this already", "stop cheating", "make a new plot before guessing, you answer hog", "the answer is RIGHT THERE", "Yeah you got your chance with this plot try a new one", "what do you think you're trying to pull here", "I come from a family of cheaters you don't think I don't recognize my own kind??", "oh please like I'd let that work, guessing when the answer is right there")
    good<- c("Wow you got this!", "Ooooh aren't you smart", "Well dang, that's not bad", "OMGERD UR PSYCHIC", "are you Shapiro?", "Wilks is that you???", "it's like the ghosts of statisticians past have possessed you", "A+! JK this isn't for credit", "Well done, two points for you Captain Smartypants", "oh DANG you got it", "mm-hmmm yep yep yep", "oooh creepily close! well done")
    
    sassifrass <- function(x){
        ifelse(x == 1, sample(good,1,replace=TRUE), sample(bad,1,replace=TRUE))
    }
    
    
    
    
    ########Score Calculator
    
    pstuff <- function(x){
        p1 <- shapiro.test(x)$p.value   #actual p value
        ifelse(p1 < .051, 2, 1)
        #ifelse(guess == should.be, 1, -1) #score
    }
    
    
    #######################REACTIVES
    
    guesses <- reactiveValues(sum = 0, points = 0)
    answers <- reactiveValues(ptalk = "", sass = "")
    rnorm1 <-  reactiveValues(x = compute_data()) #re-run Rnorm when new plot called
    vals <- reactiveValues(sum = 5, pval = 200, norm = "", sound = "smb_fireball2.mp3")
    prettyplot <- reactiveValues(col = newcolors(), fill = newcolors())
    
    #Code to update plots
    observeEvent(input$new, {
        rnorm1$x <- compute_data() #when the button is clicked, re-make the data
        guesses$sum = 0 #reset guesses to 0
        answers$ptalk = ""
        answers$sass = ""
        vals$sound = "smb_fireball2.mp3"
        prettyplot$col <- newcolors()
        prettyplot$fill <- newcolors()
    })#end of observe code 
    
    #Code to output plot
    output$distPlot <- renderPlot({
            myplot(rnorm1$x, prettyplot$fill, prettyplot$col)+
                labs(title = "")
           }) #end of plotmaking code
    
    #code to calculate if you're right
    observeEvent(input$guess, {
        vals$pval = shapiro.test(rnorm1$x)$p.value #reset the actual p value 
        guesses$sum = guesses$sum+1
        guesses$points <-  ifelse(pstuff(rnorm1$x) == input$pvalguess, 1, -1)
        vals$sound <- ifelse(pstuff(rnorm1$x) == input$pvalguess & guesses$sum == 1, "smb_coin2.mp3", ifelse(guesses$sum > 1,"smb_fireball2.mp3", "ow.mp3"))
        vals$sassmaster <- sassifrass(guesses$points)
        vals$norm = ifelse(vals$pval <.051, "probably NOT from a normal distribution", "probably from a normal distribution")
        answers$ptalk <- paste("The real p-value was ", round(vals$pval,3), "; this sample is ", vals$norm, sep="")
        
        
        
        if(guesses$sum == 1) {
            answers$sass <- vals$sassmaster
            vals$sum <- vals$sum+ guesses$points 
         # beep(sound = vals$sound, expr = NULL)
        
        } else {
            answers$sass = sample(cheat,1,replace=TRUE) #end of observeEvent for new guess button
         #   beep(sound ="www/smb_fireball.wav" )
        }
        
    })
    

        observeEvent(input$guess, {
            insertUI(selector = "#guess",
                     where = "afterBegin",
                     ui = tags$audio(src = vals$sound, type = "audio/mp3", autoplay = T, controls = NA, style="display:none;", immediate=T)
            )
        })

    
    
    output$Answer <- renderText({answers$ptalk})
    output$Sass <- renderText({answers$sass})
    output$PointsMaybe <- renderText({
       # print(paste("Your Point Total: ", vals$sum, " and number times guessed ", guesses$sum, " number plot ", input$new, sep = ""))# FOR DOUBLE CHECKING
        print(paste("Your Point Total: ", vals$sum, sep = ""))
       # print(paste("your guess:", input$guess))
    }) #end of point total
    

})
