library(shiny)
library(ggplot2)
library(dplyr)
library(fGarch)


# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Influence of Sample Size, Mean, Distribution Shape, and Standard Deviation on Normality"),
    br(),
    em("Use the input to change distribution shapes. The p values reported are from a Shapiro Wilks Normality test."),
    br(),
    em("Dashed line = median, solid = mean, dotted = standard deviations"),
    br(),
    em("Note - the mean for the bimodal distribution is split into two."),
    br(),
    br(),
    hr(),
    
    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
          sliderInput(inputId = "mean", label="Mean", min = 0, max = 100, step=1, value = 5),
          sliderInput(inputId = "sd", label="Standard Deviation", min = 0, max = 10, step=1, value = 2),
          sliderInput(inputId = "n", label="Sample Size", min = 20, max = 1000, step=10, value = 50),
          selectInput("lines", "Show Summary Stats?", choices = c("Yes", "No"), selected = "Yes")
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("distPlot")
                   
        )
    )
)

server <- function(input, output) {
  


    

  output$distPlot <- renderPlot({
    rnorm <- data.frame(x = rnorm(n = input$n, mean = input$mean, sd = input$sd), type = "Normal")
    binom <- data.frame(x =  c(rnorm(n = (input$n/2), mean = .50*input$mean, sd = .5*input$sd), rnorm(n = (input$n/2), mean = 1.5*input$mean, sd = .5*input$sd)), type = "Bimodal")
    skew <-  data.frame(x = rsnorm(input$n, mean = input$mean, sd = input$sd, xi = 3), type = "Skewed Right")
    skew2 <-  data.frame(x = rsnorm(input$n, mean = input$mean, sd = input$sd, xi = -3), type = "Skewed Left")
    together <- rbind(rnorm, binom, skew, skew2)
    
    shapteb <- together %>% 
      group_by(type) %>%
      summarize(p = shapiro.test(x)$p.value, med = median(x), sd = sd(x), mean = mean(x))
    
    together2 <- merge(together, shapteb, by="type") %>%
      mutate(ptype = paste(type, ", p value: ", round(p, 3), sep = ""))
    
    p1 <- ggplot(together2, aes(x = x, fill = type))+
      facet_wrap(~ptype)+
      geom_histogram(col = "black")+
      theme_bw()+
      theme(strip.text.x = element_text(size = 12))+
      guides(fill = FALSE)
    
    if(input$lines == "No"){
      p1
    } else {
      p1 + geom_vline(aes(xintercept = mean), lwd = 2)+
        geom_vline(aes(xintercept = med), lwd = 2, lty = 2) +
        geom_vline(aes(xintercept = mean+ sd), lty = 3, lwd = 1)+
        geom_vline(aes(xintercept = mean- sd), lty = 3, lwd = 1)+
        geom_vline(aes(xintercept = mean+ 2*sd), lty = 3, lwd = 1)+
        geom_vline(aes(xintercept = mean- 2*sd), lty = 3, lwd = 1)+
        geom_vline(aes(xintercept = mean+ 3*sd), lty = 3, lwd = 1)+
        geom_vline(aes(xintercept = mean- 3*sd), lty = 3, lwd = 1)
    }
      
    

  
  
  })
  
} #end of server  
# Run the application 
shinyApp(ui = ui, server = server)
